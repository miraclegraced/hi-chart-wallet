package com.hichart.wallet

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HiChartWallet() }
    }
}

@Composable
fun HiChartWallet() {
    var selected by remember { mutableStateOf(0) }
    MaterialTheme {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    listOf("Home","Wallet","Activity","Settings").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = selected == i,
                            onClick = { selected = i },
                            icon = { Text(listOf("⌂","◈","↕","⚙")[i], fontSize = 20.sp) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { pad ->
            Column(
                Modifier.fillMaxSize().padding(pad).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Text("Hi Chart Wallet", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("Your crypto, your control.", color = Color.Gray)

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF111827))
                ) {
                    Column(Modifier.padding(24.dp)) {
                        Text("Total Balance", color = Color.LightGray)
                        Spacer(Modifier.height(8.dp))
                        Text("₦0.00", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                        Text("Demo wallet", color = Color(0xFFB8C1D1))
                    }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ActionButton("Send")
                    ActionButton("Receive")
                    ActionButton("Swap")
                }

                Text("Assets", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                AssetRow("USDT", "Tether", "0.00")
                AssetRow("BTC", "Bitcoin", "0.00")
                AssetRow("ETH", "Ethereum", "0.00")

                Text("Recent Activity", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("No transactions yet.", color = Color.Gray)
            }
        }
    }
}

@Composable
fun RowScope.ActionButton(text: String) {
    Button(
        onClick = {},
        modifier = Modifier.weight(1f).height(48.dp),
        shape = RoundedCornerShape(14.dp)
    ) { Text(text) }
}

@Composable
fun AssetRow(symbol: String, name: String, amount: String) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(42.dp).background(Color(0xFFE5E7EB), RoundedCornerShape(21.dp)),
                contentAlignment = Alignment.Center
            ) { Text(symbol.take(1), fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(symbol, fontWeight = FontWeight.Bold)
                Text(name, color = Color.Gray, fontSize = 13.sp)
            }
            Text(amount, fontWeight = FontWeight.SemiBold)
        }
    }
}
